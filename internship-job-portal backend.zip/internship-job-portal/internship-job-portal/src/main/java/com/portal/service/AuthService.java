package com.portal.service;

import com.portal.model.Role;
import com.portal.model.User;
import com.portal.repository.UserRepository;
import com.portal.security.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


@Service
public class AuthService {
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;


	public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
	this.userRepository = userRepository;
	this.passwordEncoder = passwordEncoder;
	this.jwtUtil = jwtUtil;
	}


	public User registerStudent(String name, String email, String password) {
	if (userRepository.existsByEmail(email)) throw new RuntimeException("Email already in use");
	User u = User.builder()
	.name(name)
	.email(email)
	.password(passwordEncoder.encode(password))
	.roles(Set.of(Role.ROLE_STUDENT))
	.build();
	return userRepository.save(u);
	}


	public User registerRecruiter(String name, String email, String password) {
	if (userRepository.existsByEmail(email)) throw new RuntimeException("Email already in use");
	User u = User.builder()
	.name(name)
	.email(email)
	.password(passwordEncoder.encode(password))
	.roles(Set.of(Role.ROLE_RECRUITER))
	.build();
	return userRepository.save(u);
	}


	public String login(String email, String rawPassword) {
	Optional<User> opt = userRepository.findByEmail(email);
	if (opt.isEmpty()) throw new RuntimeException("Invalid credentials");
	User u = opt.get();
	if (!passwordEncoder.matches(rawPassword, u.getPassword())) throw new RuntimeException("Invalid credentials");


	var roles = u.getRoles().stream().map(Role::name).collect(Collectors.toList());
	return jwtUtil.generateToken(u.getEmail(), roles);
	}

}
