package com.portal.controller;


import com.portal.model.ApplicationEntity;
import com.portal.service.ApplicationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

	private final ApplicationService applicationService;


	public ApplicationController(ApplicationService applicationService) {
	this.applicationService = applicationService;
	}


	@PostMapping("/job/{jobId}")
	public ResponseEntity<ApplicationEntity> applyJob(@PathVariable Long jobId, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(applicationService.applyForJob(jobId, email));
	}


	@PostMapping("/internship/{internshipId}")
	public ResponseEntity<ApplicationEntity> applyInternship(@PathVariable Long internshipId, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(applicationService.applyForInternship(internshipId, email));
	}


	@GetMapping("/me")
	public ResponseEntity<List<ApplicationEntity>> myApplications(Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(applicationService.listByApplicant(email));
	}
}
