package com.portal.model;

import jakarta.persistence.*;
import lombok.*;


import java.time.Instant;
@Entity
@Table(name = "applications")
@Builder
public class ApplicationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	@ManyToOne
	@JoinColumn(name = "applicant_id")
	private User applicant;


	@ManyToOne
	@JoinColumn(name = "job_id")
	private Job job; // nullable if internship applied


	public ApplicationEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ApplicationEntity(Long id, User applicant, Job job, Internship internship, String status,
			Instant appliedAt) {
		super();
		this.id = id;
		this.applicant = applicant;
		this.job = job;
		this.internship = internship;
		this.status = status;
		this.appliedAt = appliedAt;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public User getApplicant() {
		return applicant;
	}


	public void setApplicant(User applicant) {
		this.applicant = applicant;
	}


	public Job getJob() {
		return job;
	}


	public void setJob(Job job) {
		this.job = job;
	}


	public Internship getInternship() {
		return internship;
	}


	public void setInternship(Internship internship) {
		this.internship = internship;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Instant getAppliedAt() {
		return appliedAt;
	}


	public void setAppliedAt(Instant appliedAt) {
		this.appliedAt = appliedAt;
	}


	@ManyToOne
	@JoinColumn(name = "internship_id")
	private Internship internship; // nullable if job applied


	private String status; // APPLIED, REVIEWED, REJECTED, ACCEPTED


	private Instant appliedAt;

}
