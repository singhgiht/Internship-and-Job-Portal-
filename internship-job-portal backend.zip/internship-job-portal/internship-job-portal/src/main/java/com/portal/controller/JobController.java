package com.portal.controller;

import com.portal.model.Job;
import com.portal.service.JobService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/jobs")
public class JobController {
	private final JobService jobService;


	public JobController(JobService jobService) {
	this.jobService = jobService;
	}


	@GetMapping
	public ResponseEntity<List<Job>> listActive() {
	return ResponseEntity.ok(jobService.listActiveJobs());
	}


	@GetMapping("/{id}")
	public ResponseEntity<Job> get(@PathVariable Long id) {
	return ResponseEntity.ok(jobService.getById(id));
	}


	@PostMapping
	public ResponseEntity<Job> create(@RequestBody Job job, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(jobService.createJob(job, email));
	}


	@PutMapping("/{id}")
	public ResponseEntity<Job> update(@PathVariable Long id, @RequestBody Job job, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(jobService.updateJob(job, id, email));
	}


	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
	String email = auth.getName();
	jobService.deleteJob(id, email);
	return ResponseEntity.noContent().build();
	}
}

