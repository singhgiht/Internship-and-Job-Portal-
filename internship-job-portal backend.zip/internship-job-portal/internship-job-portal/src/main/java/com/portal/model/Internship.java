package com.portal.model;



import jakarta.persistence.*;
import lombok.Builder;

import java.time.Instant;
@Entity
@Builder
public class Internship {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;


	private String title;


	@Column(length = 5000)
	private String description;


	public Internship() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Internship(Long id, String title, String description, String location, Instant createdAt, Boolean active,
			User recruiter) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.location = location;
		this.createdAt = createdAt;
		this.active = active;
		this.recruiter = recruiter;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public Instant getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}


	public Boolean getActive() {
		return active;
	}


	public void setActive(Boolean active) {
		this.active = active;
	}


	public User getRecruiter() {
		return recruiter;
	}


	public void setRecruiter(User recruiter) {
		this.recruiter = recruiter;
	}


	private String location;


	private Instant createdAt;


	private Boolean active = true;


	@ManyToOne
	@JoinColumn(name = "recruiter_id")
	private User recruiter;
}
