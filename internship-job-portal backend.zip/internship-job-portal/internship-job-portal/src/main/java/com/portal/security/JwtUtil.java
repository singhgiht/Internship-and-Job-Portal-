package com.portal.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


import java.security.Key;
import java.util.Date;
import java.util.List;

@Component
public class JwtUtil {

	private final Key key;
	private final long jwtExpirationMs;


	public JwtUtil(@Value("${app.jwt.secret}") String jwtSecret,
	@Value("${app.jwt.expiration-ms}") long jwtExpirationMs) {
	// For simplicity, derive a key from secret bytes. In production use a properly sized secret.
	this.key = Keys.hmacShaKeyFor(jwtSecret.getBytes());
	this.jwtExpirationMs = jwtExpirationMs;
	}


	public String generateToken(String username, List<String> roles) {
	Date now = new Date();
	Date expiry = new Date(now.getTime() + jwtExpirationMs);


	return Jwts.builder()
	.setSubject(username)
	.claim("roles", roles)
	.setIssuedAt(now)
	.setExpiration(expiry)
	.signWith(key, SignatureAlgorithm.HS256)
	.compact();
	}


	public Claims validateAndGetClaims(String token) {
	return Jwts.parserBuilder()
	.setSigningKey(key)
	.build()
	.parseClaimsJws(token)
	.getBody();
	}
}
