package com.portal.service;

import com.portal.model.Job;
import com.portal.model.User;
import com.portal.repository.JobRepository;
import com.portal.repository.UserRepository;
import org.springframework.stereotype.Service;


import java.time.Instant;
import java.util.List;


@Service
public class JobService {
	private final JobRepository jobRepository;
	private final UserRepository userRepository;


	public JobService(JobRepository jobRepository, UserRepository userRepository) {
	this.jobRepository = jobRepository;
	this.userRepository = userRepository;
	}


	public Job createJob(Job job, String recruiterEmail) {
	User rec = userRepository.findByEmail(recruiterEmail).orElseThrow(() -> new RuntimeException("Recruiter not found"));
	job.setRecruiter(rec);
	job.setCreatedAt(Instant.now());
	return jobRepository.save(job);
	}


	public List<Job> listActiveJobs() {
	return jobRepository.findByActiveTrueOrderByCreatedAtDesc();
	}


	public Job getById(Long id) {
	return jobRepository.findById(id).orElseThrow(() -> new RuntimeException("Job not found"));
	}


	public Job updateJob(Job job, Long id, String recruiterEmail) {
	Job existing = getById(id);
	if (!existing.getRecruiter().getEmail().equals(recruiterEmail)) throw new RuntimeException("Not allowed");
	existing.setTitle(job.getTitle());
	existing.setDescription(job.getDescription());
	existing.setLocation(job.getLocation());
	existing.setActive(job.getActive());
	return jobRepository.save(existing);
	}


	public void deleteJob(Long id, String recruiterEmail) {
	Job existing = getById(id);
	if (!existing.getRecruiter().getEmail().equals(recruiterEmail)) throw new RuntimeException("Not allowed");
	jobRepository.delete(existing);
	}

}
