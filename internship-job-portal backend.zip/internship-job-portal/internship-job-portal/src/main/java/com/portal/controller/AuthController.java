package com.portal.controller;

import com.portal.model.User;
import com.portal.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.Map;


@RestController
@RequestMapping("/api/auth")
public class AuthController {

	private final AuthService authService;


	public AuthController(AuthService authService) {
	this.authService = authService;
	}


	record RegisterRequest(String name, String email, String password) {}
	record LoginRequest(String email, String password) {}


	@PostMapping("/register/student")
	public ResponseEntity<?> registerStudent(@Valid @RequestBody RegisterRequest req) {
	User u = authService.registerStudent(req.name(), req.email(), req.password());
	return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail()));
	}


	@PostMapping("/register/recruiter")
	public ResponseEntity<?> registerRecruiter(@Valid @RequestBody RegisterRequest req) {
	User u = authService.registerRecruiter(req.name(), req.email(), req.password());
	return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail()));
	}


	@PostMapping("/login")
	public ResponseEntity<?> login(@Valid @RequestBody LoginRequest req) {
	String token = authService.login(req.email(), req.password());
	return ResponseEntity.ok(Map.of("token", token));
	}
}
