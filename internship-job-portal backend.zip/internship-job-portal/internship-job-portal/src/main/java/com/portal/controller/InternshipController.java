package com.portal.controller;

import com.portal.model.Internship;
import com.portal.service.InternshipService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/internships")
public class InternshipController {
	private final InternshipService internshipService;


	public InternshipController(InternshipService internshipService) {
	this.internshipService = internshipService;
	}


	@GetMapping
	public ResponseEntity<List<Internship>> listActive() {
	return ResponseEntity.ok(internshipService.listActive());
	}


	@GetMapping("/{id}")
	public ResponseEntity<Internship> get(@PathVariable Long id) {
	return ResponseEntity.ok(internshipService.getById(id));
	}


	@PostMapping
	public ResponseEntity<Internship> create(@RequestBody Internship internship, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(internshipService.createInternship(internship, email));
	}


	@PutMapping("/{id}")
	public ResponseEntity<Internship> update(@PathVariable Long id, @RequestBody Internship internship, Authentication auth) {
	String email = auth.getName();
	return ResponseEntity.ok(internshipService.updateInternship(internship, id, email));
	}


	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id, Authentication auth) {
	String email = auth.getName();
	internshipService.deleteInternship(id, email);
	return ResponseEntity.noContent().build();
	}

}
