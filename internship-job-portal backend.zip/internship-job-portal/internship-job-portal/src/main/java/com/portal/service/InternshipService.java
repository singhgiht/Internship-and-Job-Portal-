package com.portal.service;
import com.portal.model.Internship;
import com.portal.model.User;
import com.portal.repository.InternshipRepository;
import com.portal.repository.UserRepository;
import org.springframework.stereotype.Service;


import java.time.Instant;
import java.util.List;


@Service
public class InternshipService {

	private final InternshipRepository internshipRepository;
	private final UserRepository userRepository;


	public InternshipService(InternshipRepository internshipRepository, UserRepository userRepository) {
	this.internshipRepository = internshipRepository;
	this.userRepository = userRepository;
	}


	public Internship createInternship(Internship internship, String recruiterEmail) {
	User rec = userRepository.findByEmail(recruiterEmail).orElseThrow(() -> new RuntimeException("Recruiter not found"));
	internship.setRecruiter(rec);
	internship.setCreatedAt(Instant.now());
	return internshipRepository.save(internship);
	}


	public List<Internship> listActive() {
	return internshipRepository.findByActiveTrueOrderByCreatedAtDesc();
	}


	public Internship getById(Long id) {
	return internshipRepository.findById(id).orElseThrow(() -> new RuntimeException("Internship not found"));
	}


	public Internship updateInternship(Internship internship, Long id, String recruiterEmail) {
	Internship existing = getById(id);
	if (!existing.getRecruiter().getEmail().equals(recruiterEmail)) throw new RuntimeException("Not allowed");
	existing.setTitle(internship.getTitle());
	existing.setDescription(internship.getDescription());
	existing.setLocation(internship.getLocation());
	existing.setActive(internship.getActive());
	return internshipRepository.save(existing);
	}


	public void deleteInternship(Long id, String recruiterEmail) {
	Internship existing = getById(id);
	if (!existing.getRecruiter().getEmail().equals(recruiterEmail)) throw new RuntimeException("Not allowed");
	internshipRepository.delete(existing);
	}
}
