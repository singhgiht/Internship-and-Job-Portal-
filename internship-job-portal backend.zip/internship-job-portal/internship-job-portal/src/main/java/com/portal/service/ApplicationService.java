package com.portal.service;

import com.portal.model.*;
import com.portal.repository.*;
import org.springframework.stereotype.Service;


import java.time.Instant;
import java.util.List;


@Service
public class ApplicationService {

	private final ApplicationRepository applicationRepository;
	private final UserRepository userRepository;
	private final JobRepository jobRepository;
	private final InternshipRepository internshipRepository;


	public ApplicationService(ApplicationRepository applicationRepository, UserRepository userRepository, JobRepository jobRepository, InternshipRepository internshipRepository) {
	this.applicationRepository = applicationRepository;
	this.userRepository = userRepository;
	this.jobRepository = jobRepository;
	this.internshipRepository = internshipRepository;
	}


	public ApplicationEntity applyForJob(Long jobId, String applicantEmail) {
	User applicant = userRepository.findByEmail(applicantEmail).orElseThrow(() -> new RuntimeException("User not found"));
	Job job = jobRepository.findById(jobId).orElseThrow(() -> new RuntimeException("Job not found"));


	ApplicationEntity a = ApplicationEntity.builder()
	.applicant(applicant)
	.job(job)
	.internship(null)
	.status("APPLIED")
	.appliedAt(Instant.now())
	.build();
	return applicationRepository.save(a);
	}


	public ApplicationEntity applyForInternship(Long internshipId, String applicantEmail) {
	User applicant = userRepository.findByEmail(applicantEmail).orElseThrow(() -> new RuntimeException("User not found"));
	Internship internship = internshipRepository.findById(internshipId).orElseThrow(() -> new RuntimeException("Internship not found"));


	ApplicationEntity a = ApplicationEntity.builder()
	.applicant(applicant)
	.job(null)
	.internship(internship)
	.status("APPLIED")
	.appliedAt(Instant.now())
	.build();
	return applicationRepository.save(a);
	}


	public List<ApplicationEntity> listByApplicant(String email) {
	User u = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
	return applicationRepository.findByApplicant(u);
	}
}
