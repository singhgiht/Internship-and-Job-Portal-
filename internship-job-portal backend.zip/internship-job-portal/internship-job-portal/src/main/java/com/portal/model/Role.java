package com.portal.model;

public enum Role {
		ROLE_ADMIN,
		ROLE_RECRUITER,
		ROLE_STUDENT
}
