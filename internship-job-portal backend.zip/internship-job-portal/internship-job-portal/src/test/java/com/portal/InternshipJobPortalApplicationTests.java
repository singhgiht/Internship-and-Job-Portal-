package com.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipJobPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
