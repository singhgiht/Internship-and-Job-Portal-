import { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState('');
  const navigate = useNavigate();
  async function submit(e){ e.preventDefault(); setErr(''); try{ await api.post('/auth/register/student',{name,email,password}); navigate('/login'); }catch(e){ setErr('Register failed') } }
  return (<div className="row justify-content-center"><div className="col-md-6"><h3>Register (Student)</h3>{err && <div className="alert alert-danger">{err}</div>}<form onSubmit={submit}><div className="mb-2"><label>Name</label><input className="form-control" value={name} onChange={e=>setName(e.target.value)} required/></div><div className="mb-2"><label>Email</label><input className="form-control" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="mb-2"><label>Password</label><input type="password" className="form-control" value={password} onChange={e=>setPassword(e.target.value)} required/></div><button className="btn btn-primary">Register</button></form></div></div>)
}