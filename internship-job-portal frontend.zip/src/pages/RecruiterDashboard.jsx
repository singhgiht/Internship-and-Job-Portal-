import { useEffect, useState } from 'react';
import api from '../services/api';

export default function RecruiterDashboard(){
  const [jobs,setJobs]=useState([]);
  const [title,setTitle]=useState(''); const [desc,setDesc]=useState(''); const [loc,setLoc]=useState(''); const [msg,setMsg]=useState('');
  useEffect(()=>{ api.get('/jobs').then(r=>setJobs(r.data)).catch(()=>{}); },[]);
  async function postJob(e){ e.preventDefault(); setMsg(''); try{ await api.post('/jobs', { title, description: desc, location: loc }); setMsg('Job posted'); setTitle(''); setDesc(''); setLoc(''); api.get('/jobs').then(r=>setJobs(r.data)); }catch(e){ setMsg('Post failed') } }
  async function viewApplicants(jobId){ try{ const res = await api.get('/jobs/'+jobId+'/applications'); alert(JSON.stringify(res.data, null, 2)); }catch(e){ alert('Could not fetch applicants — endpoint may not exist on backend') } }
  return (<div><h3>Recruiter Dashboard</h3>{msg && <div className="alert alert-info">{msg}</div>}<div className="row"><div className="col-md-6"><h5>Post Job</h5><form onSubmit={postJob}><div className="mb-2"><label>Title</label><input className="form-control" value={title} onChange={e=>setTitle(e.target.value)} required/></div><div className="mb-2"><label>Location</label><input className="form-control" value={loc} onChange={e=>setLoc(e.target.value)} required/></div><div className="mb-2"><label>Description</label><textarea className="form-control" value={desc} onChange={e=>setDesc(e.target.value)} required/></div><button className="btn btn-primary">Post</button></form></div><div className="col-md-6"><h5>Your Jobs</h5>{jobs.map(j=> (<div key={j.id} className="card mb-2 p-2"><strong>{j.title}</strong><div className="text-muted">{j.location}</div><div className="mt-2"><button className="btn btn-sm btn-outline-primary" onClick={()=>viewApplicants(j.id)}>View Applicants</button></div></div>))}</div></div></div>)
}