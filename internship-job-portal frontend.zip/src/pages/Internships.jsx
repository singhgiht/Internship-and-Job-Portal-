import { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

export default function Internships(){
  const [items,setItems]=useState([]);
  useEffect(()=>{ api.get('/internships').then(r=>setItems(r.data)).catch(()=>{}); },[]);
  return (<div><h3>Internships</h3><div className="row">{items.map(i=> (<div className="col-md-4" key={i.id}><div className="card mb-3"><div className="card-body"><h5>{i.title}</h5><p className="text-muted">{i.location}</p><p style={{height:70,overflow:'hidden'}}>{i.description}</p></div></div></div>))}</div></div>)
}