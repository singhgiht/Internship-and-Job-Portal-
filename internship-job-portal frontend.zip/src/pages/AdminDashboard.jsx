import { useEffect, useState } from 'react';
import api from '../services/api';

export default function AdminDashboard(){
  const [users,setUsers]=useState([]);
  const [msg,setMsg]=useState('');
  useEffect(()=>{ api.get('/users').then(r=>setUsers(r.data)).catch(()=>{}); },[]);
  async function removeUser(id){ try{ await api.delete('/users/'+id); setMsg('User removed'); api.get('/users').then(r=>setUsers(r.data)); }catch(e){ setMsg('Failed') } }
  return (<div><h3>Admin Dashboard</h3>{msg && <div className="alert alert-info">{msg}</div>}<div>{users.length? users.map(u=> (<div className="card mb-2 p-2" key={u.id}><strong>{u.name||u.email}</strong><div>{u.email}</div><div className="mt-2"><button className="btn btn-sm btn-danger" onClick={()=>removeUser(u.id)}>Remove</button></div></div>)) : <p>No users or endpoint /api/users not available on backend.</p>}</div></div>)
}