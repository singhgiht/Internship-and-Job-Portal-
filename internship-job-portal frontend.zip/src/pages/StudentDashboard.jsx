import { useEffect, useState } from 'react';
import api from '../services/api';

export default function StudentDashboard(){
  const [jobs,setJobs]=useState([]);
  const [interns,setInterns]=useState([]);
  const [applications,setApplications]=useState([]);
  const [msg,setMsg]=useState('');
  useEffect(()=>{ api.get('/jobs').then(r=>setJobs(r.data)).catch(()=>{}); api.get('/internships').then(r=>setInterns(r.data)).catch(()=>{}); api.get('/applications/me').then(r=>setApplications(r.data)).catch(()=>{}); },[]);
  async function applyJob(id){
    setMsg(''); try{ await api.post('/applications/job/'+id); setMsg('Applied to job'); api.get('/applications/me').then(r=>setApplications(r.data)); }catch(e){ setMsg('Apply failed') }
  }
  async function applyIntern(id){
    setMsg(''); try{ await api.post('/applications/internship/'+id); setMsg('Applied to internship'); api.get('/applications/me').then(r=>setApplications(r.data)); }catch(e){ setMsg('Apply failed') }
  }
  return (<div><h3>Student Dashboard</h3>{msg && <div className="alert alert-info">{msg}</div>}<div className="row"><div className="col-md-6"><h5>Jobs</h5>{jobs.map(j=> (<div key={j.id} className="card mb-2 p-2"><h6>{j.title}</h6><p className="text-muted">{j.location}</p><div><button className="btn btn-sm btn-primary me-2" onClick={()=>applyJob(j.id)}>Apply</button></div></div>))}</div><div className="col-md-6"><h5>My Applications</h5>{applications.map(a=> (<div key={a.id} className="card mb-2 p-2"><strong>{a.job? a.job.title : a.internship? a.internship.title : 'Application'}</strong><div>Status: {a.status}</div></div>))}</div></div></div>)
}