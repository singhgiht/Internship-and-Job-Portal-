import { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

export default function Jobs(){
  const [jobs,setJobs]=useState([]);
  useEffect(()=>{ api.get('/jobs').then(r=>setJobs(r.data)).catch(()=>{}); },[]);
  return (<div><h3>Jobs</h3><div className="row">{jobs.map(j=> (<div className="col-md-4" key={j.id}><div className="card mb-3"><div className="card-body"><h5>{j.title}</h5><p className="text-muted">{j.location}</p><p style={{height:70,overflow:'hidden'}}>{j.description}</p><Link to={'/jobs/'+j.id} className="btn btn-sm btn-primary">View</Link></div></div></div>))}</div></div>)
}