import { useEffect, useState } from 'react';
import api from '../services/api';
export default function Profile(){
  const [user,setUser]=useState(null);
  useEffect(()=>{ api.get('/auth/me').then(r=>setUser(r.data)).catch(()=>{}); },[]);
  return (<div><h3>Profile</h3>{user? <pre>{JSON.stringify(user, null, 2)}</pre> : <p>Load failed or not logged in</p>}</div>)
}