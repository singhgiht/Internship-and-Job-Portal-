import { Link, useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const logout = ()=>{ localStorage.removeItem("token"); navigate('/login') }
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Zidio Portal</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navmenu">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><Link className="nav-link" to="/jobs">Jobs</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/internships">Internships</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/student">Student</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/recruiter">Recruiter</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/admin">Admin</Link></li>
            {token ? (
              <li className="nav-item"><button className="btn btn-sm btn-outline-light ms-2" onClick={logout}>Logout</button></li>
            ) : (
              <li className="nav-item"><Link className="nav-link" to="/login">Login</Link></li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;